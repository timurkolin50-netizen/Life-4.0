# Загрузка LIFE 3.0.4 в GitHub

1. Распакуйте этот ZIP на компьютере.
2. В репозитории GitHub откройте **Add file → Upload files**.
3. Загружайте содержимое папки `life_final` так, чтобы в корне репозитория были:
   - `settings.gradle.kts`
   - `build.gradle.kts`
   - `gradle.properties`
   - папка `app`
   - папка `.github`
4. Не оставляйте дополнительную папку `life_final` между корнем репозитория и этими файлами.
5. Сделайте Commit changes.
6. Откройте Actions → **Build LIFE APK** → **Run workflow**.

Важно: ZIP не нужно загружать как единственный файл в репозиторий. GitHub Actions должен видеть `app/` и `settings.gradle.kts` непосредственно в корне.
