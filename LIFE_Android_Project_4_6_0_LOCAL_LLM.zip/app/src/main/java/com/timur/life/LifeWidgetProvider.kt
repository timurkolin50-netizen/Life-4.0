package com.timur.life

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZonedDateTime
import java.time.ZoneId

class LifeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val now = ZonedDateTime.now(ZoneId.of("Europe/Vilnius"))
        val time = now.toLocalTime().toString().take(5)
        val date = now.toLocalDate().toString()

        ids.forEach { id ->
            manager.updateAppWidget(id, baseViews(context, time, "Сегодня • $date"))
        }

        val client = try {
            HealthConnectClient.getOrCreate(context)
        } catch (_: Exception) {
            null
        } ?: return

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val start = now.toLocalDate().atStartOfDay(now.zone).toInstant()
                val result = client.aggregate(
                    AggregateRequest(
                        metrics = setOf(StepsRecord.COUNT_TOTAL),
                        timeRangeFilter = TimeRangeFilter.between(start, Instant.now())
                    )
                )
                val steps = result[StepsRecord.COUNT_TOTAL] ?: 0L
                ids.forEach { id ->
                    manager.updateAppWidget(
                        id,
                        baseViews(context, time, "Сегодня • $steps шагов")
                    )
                }
            } catch (_: Exception) {
                // The widget remains usable even when Health Connect is unavailable.
            }
        }
    }

    private fun baseViews(context: Context, time: String, info: String): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.life_widget)
        views.setTextViewText(R.id.widget_time, time)
        views.setTextViewText(R.id.widget_info, info)
        val intent = Intent(context, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_root, pending)
        return views
    }
}
