package com.timur.life

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.ZoneId
import java.util.Calendar
import java.util.TimeZone

object ReminderScheduler {
    private const val BASE_CODE = 20_000
    private val zone = ZoneId.of("Europe/Vilnius")

    private val reminders = listOf(
        Triple(9, 0, "Доброе утро"),
        Triple(10, 0, "Выпей воды · 250–500 мл"),
        Triple(12, 0, "Выпей воды · проверь цель"),
        Triple(14, 0, "Вода · ещё один стакан"),
        Triple(16, 0, "Выпей воды и пройдись 5–10 минут"),
        Triple(18, 0, "Пора выпить воды"),
        Triple(20, 0, "Последний стакан воды на сегодня"),
        Triple(11, 30, "Ходи больше · сделай короткую прогулку"),
        Triple(15, 30, "Разомнись · 5 минут движения"),
        Triple(19, 30, "Прогуляйся 10–20 минут"),
        Triple(22, 30, "Подготовься ко сну · отложи телефон")
    )

    fun schedule(context: Context) {
        val alarmManager = context.getSystemService(AlarmManager::class.java)
        reminders.forEachIndexed { index, item ->
            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra("title", "LIFE")
                putExtra("text", item.third)
            }
            val pending = PendingIntent.getBroadcast(
                context, BASE_CODE + index, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val calendar = Calendar.getInstance(TimeZone.getTimeZone(zone)).apply {
                set(Calendar.HOUR_OF_DAY, item.first)
                set(Calendar.MINUTE, item.second)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                pending
            )
        }
    }

    fun cancel(context: Context) {
        val alarmManager = context.getSystemService(AlarmManager::class.java)
        reminders.indices.forEach { index ->
            val intent = Intent(context, ReminderReceiver::class.java)
            val pending = PendingIntent.getBroadcast(
                context, BASE_CODE + index, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pending)
            pending.cancel()
        }
    }
}
