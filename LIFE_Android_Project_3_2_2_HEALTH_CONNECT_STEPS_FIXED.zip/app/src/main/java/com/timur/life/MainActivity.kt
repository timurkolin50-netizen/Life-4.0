package com.timur.life

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.contracts.HealthPermissionsRequestContract
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZonedDateTime
import java.util.Calendar

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var healthClient: HealthConnectClient? = null
    private var healthPermissionLauncher: ActivityResultLauncher<Set<String>>? = null
    private val channelId = "life_general"

    private val healthPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        healthPermissionLauncher = registerForActivityResult(
            HealthPermissionsRequestContract()
        ) {
            healthClient = try {
                HealthConnectClient.getOrCreate(this@MainActivity)
            } catch (_: Exception) {
                null
            }
            syncHealthToWeb()
        }


        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                100
            )
        }

        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(
                    channelId,
                    "LIFE",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
            )
        }

        web = WebView(this).apply {
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            addJavascriptInterface(LifeBridge(), "LIFEAndroid")
            loadUrl("file:///android_asset/index.html")
        }

        setContentView(web)
    }

    override fun onResume() {
        super.onResume()
        // The direct Health Connect permissions screen does not call the
        // ActivityResult launcher, so initialize the client and refresh every
        // time LIFE returns to the foreground.
        healthClient = try {
            HealthConnectClient.getOrCreate(this)
        } catch (_: Exception) {
            null
        }
        syncHealthToWeb()
    }

    private fun syncHealthToWeb() {
        val client = healthClient ?: run {
            healthClient = try { HealthConnectClient.getOrCreate(this) } catch (_: Exception) { null }
            healthClient ?: return
        }

        CoroutineScope(Dispatchers.IO).launch {
            val now = ZonedDateTime.now()
            val start = now.toLocalDate().atStartOfDay(now.zone).toInstant()
            val range = TimeRangeFilter.between(start, Instant.now())

            var steps = 0L
            var distance = 0.0
            var calories = 0.0

            // Read each metric independently. A failure in distance/calories
            // must never prevent LIFE from receiving the step count.
            try {
                val result = client.aggregate(
                    AggregateRequest(
                        metrics = setOf(StepsRecord.COUNT_TOTAL),
                        timeRangeFilter = range
                    )
                )
                steps = result[StepsRecord.COUNT_TOTAL] ?: 0L
            } catch (_: Exception) {
                // Keep steps at zero if Health Connect refuses this read.
            }

            try {
                val result = client.aggregate(
                    AggregateRequest(
                        metrics = setOf(DistanceRecord.DISTANCE_TOTAL),
                        timeRangeFilter = range
                    )
                )
                distance = result[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0
            } catch (_: Exception) {
                // Distance is optional for the step sync.
            }

            try {
                val result = client.aggregate(
                    AggregateRequest(
                        metrics = setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
                        timeRangeFilter = range
                    )
                )
                calories = result[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
            } catch (_: Exception) {
                // Calories are optional for the step sync.
            }

            withContext(Dispatchers.Main) {
                if (::web.isInitialized) {
                    web.evaluateJavascript(
                        "window.LIFEHealth && window.LIFEHealth($steps,$distance,$calories);",
                        null
                    )
                }
            }
        }
    }

    inner class LifeBridge {
        @JavascriptInterface
        fun notify(title: String, text: String) {
            val notification = NotificationCompat.Builder(this@MainActivity, channelId)
                .setSmallIcon(R.drawable.ic_life)
                .setContentTitle(title.take(80))
                .setContentText(text.take(180))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()

            getSystemService(NotificationManager::class.java).notify(
                (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
                notification
            )
        }

        @JavascriptInterface
        fun openHealth() {
            try {
                val intent = Intent(
                    "android.health.connect.action.MANAGE_HEALTH_PERMISSIONS"
                ).apply {
                    putExtra(Intent.EXTRA_PACKAGE_NAME, packageName)
                }
                startActivity(intent)
                return
            } catch (_: Exception) {
                // Continue with the Health Connect settings intent.
            }

            try {
                startActivity(
                    HealthConnectClient.getHealthConnectManageDataIntent(
                        this@MainActivity
                    )
                )
            } catch (_: Exception) {
                try {
                    startActivity(Intent(HealthConnectClient.ACTION_HEALTH_CONNECT_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(
                        this@MainActivity,
                        "Не удалось открыть Health Connect",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        @JavascriptInterface
        fun connectHealth() {
            // Open the official Health Connect permissions UI directly for LIFE.
            // This bypasses SDK-status checks and lets Android/Health Connect
            // handle the permission screen.
            try {
                val intent = Intent(
                    "android.health.connect.action.MANAGE_HEALTH_PERMISSIONS"
                ).apply {
                    putExtra(Intent.EXTRA_PACKAGE_NAME, packageName)
                }
                startActivity(intent)
            } catch (_: Exception) {
                // Fallback: open the main Health Connect UI.
                try {
                    startActivity(
                        HealthConnectClient.getHealthConnectManageDataIntent(
                            this@MainActivity
                        )
                    )
                } catch (_: Exception) {
                    try {
                        startActivity(
                            Intent(HealthConnectClient.ACTION_HEALTH_CONNECT_SETTINGS)
                        )
                    } catch (_: Exception) {
                        Toast.makeText(
                            this@MainActivity,
                            "Не удалось открыть Health Connect",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }

        @JavascriptInterface
        fun refreshHealth() {
            syncHealthToWeb()
        }

        @JavascriptInterface
        fun scheduleDaily(title: String, text: String, hour: Int, minute: Int) {
            val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
            val intent = Intent(this@MainActivity, ReminderReceiver::class.java).apply {
                putExtra("title", title)
                putExtra("text", text)
            }
            val requestCode = title.hashCode() and 0x7fffffff
            val pendingIntent = PendingIntent.getBroadcast(
                this@MainActivity,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
                set(Calendar.MINUTE, minute.coerceIn(0, 59))
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }

            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                pendingIntent
            )
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Exception) {
                // Ignore invalid or unsupported URLs.
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) syncHealthToWeb()
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.removeJavascriptInterface("LIFEAndroid")
            web.destroy()
        }
        super.onDestroy()
    }
}
