package com.timur.life

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.DayOfWeek
import java.time.ZoneId
import java.time.ZonedDateTime

/** Reliable recurring reminders for planner items. All calendar calculations use Klaipeda/Vilnius time. */
class PlanReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", 0L)
        val title = intent.getStringExtra("task_title") ?: "Задача LIFE"
        val repeat = intent.getStringExtra("repeat") ?: "none"
        val hour = intent.getIntExtra("hour", 9).coerceIn(0, 23)
        val minute = intent.getIntExtra("minute", 0).coerceIn(0, 59)
        val reminder = intent.getIntExtra("reminder", 0).coerceIn(0, 60)

        context.sendBroadcast(Intent(context, ReminderReceiver::class.java).apply { putExtra("title", "LIFE · План"); putExtra("text", title.take(180)) })
        if (repeat != "none") schedule(context, id, title, hour, minute, repeat, reminder)
    }

    companion object {
        private const val PREFS = "life_plan_alarms"
        private const val KEY_IDS = "ids"
        private val ZONE = ZoneId.of("Europe/Vilnius")

        fun schedule(context: Context, id: Long, title: String, hour: Int, minute: Int, repeat: String, reminderMinutes: Int) {
            if (id <= 0) return
            if (repeat == "none") {
                scheduleAt(context, id, title, hour, minute, repeat, reminderMinutes, nextOneOff(hour, minute))
                return
            }
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("$id", encode(title, hour, minute, repeat, reminderMinutes)).apply()
            val ids = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet(KEY_IDS, emptySet())!!.toMutableSet()
            ids.add(id.toString())
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY_IDS, ids).apply()
            scheduleAt(context, id, title, hour, minute, repeat, reminderMinutes, nextOccurrence(hour, minute, repeat))
        }

        fun cancel(context: Context, id: Long) {
            if (id <= 0) return
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = pending(context, id, null, 0, 0, "none", 0)
            am.cancel(pi); pi.cancel()
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            prefs.edit().remove(id.toString()).apply()
            val ids = prefs.getStringSet(KEY_IDS, emptySet())!!.toMutableSet()
            ids.remove(id.toString())
            prefs.edit().putStringSet(KEY_IDS, ids).apply()
        }

        fun rescheduleAll(context: Context) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val ids = prefs.getStringSet(KEY_IDS, emptySet()) ?: emptySet()
            ids.forEach { rawId ->
                val id = rawId.toLongOrNull() ?: return@forEach
                val data = prefs.getString(rawId, null) ?: return@forEach
                val parts = data.split("|", limit = 5)
                if (parts.size < 5) return@forEach
                val title = parts[0].replace("\\p", "|")
                val hour = parts[1].toIntOrNull() ?: 9
                val minute = parts[2].toIntOrNull() ?: 0
                val repeat = parts[3]
                val reminder = parts[4].toIntOrNull() ?: 0
                scheduleAt(context, id, title, hour, minute, repeat, reminder, nextOccurrence(hour, minute, repeat))
            }
        }

        private fun encode(title: String, hour: Int, minute: Int, repeat: String, reminder: Int) =
            "${title.replace("|", "\\p")}|$hour|$minute|$repeat|$reminder"

        private fun nextOneOff(hour: Int, minute: Int): ZonedDateTime {
            val now = ZonedDateTime.now(ZONE)
            var t = now.toLocalDate().atTime(hour, minute).atZone(ZONE)
            if (!t.isAfter(now)) t = t.plusDays(1)
            return t
        }

        private fun nextOccurrence(hour: Int, minute: Int, repeat: String): ZonedDateTime {
            val now = ZonedDateTime.now(ZONE)
            var t = now.toLocalDate().atTime(hour, minute).atZone(ZONE)
            if (!t.isAfter(now)) t = t.plusDays(1)
            while (!allowed(t.dayOfWeek, repeat)) t = t.plusDays(1)
            return t
        }

        private fun allowed(day: DayOfWeek, repeat: String) = when (repeat) {
            "daily" -> true
            "weekdays" -> day.value in 1..5
            "weekends" -> day.value >= 6
            else -> false
        }

        private fun scheduleAt(context: Context, id: Long, title: String, hour: Int, minute: Int, repeat: String, reminder: Int, time: ZonedDateTime) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = pending(context, id, title, hour, minute, repeat, reminder)
            val trigger = time.minusMinutes(reminder.toLong()).toInstant().toEpochMilli()
            if (trigger <= System.currentTimeMillis()) return
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        }

        private fun pending(context: Context, id: Long, title: String?, hour: Int, minute: Int, repeat: String, reminder: Int): PendingIntent {
            val intent = Intent(context, PlanReminderReceiver::class.java).apply {
                putExtra("id", id); putExtra("task_title", title ?: "Задача LIFE")
                putExtra("hour", hour); putExtra("minute", minute); putExtra("repeat", repeat); putExtra("reminder", reminder)
            }
            return PendingIntent.getBroadcast(context, (id and 0x7fffffff).toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
    }
}
