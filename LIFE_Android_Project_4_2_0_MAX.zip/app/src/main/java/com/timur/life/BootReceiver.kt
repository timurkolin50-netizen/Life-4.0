package com.timur.life

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val enabled = context.getSharedPreferences("life_settings", Context.MODE_PRIVATE).getBoolean("health_reminders_enabled", true)
            if (enabled) ReminderScheduler.schedule(context)
        }
    }
}
