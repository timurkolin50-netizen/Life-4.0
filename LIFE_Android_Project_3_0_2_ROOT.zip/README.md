# LIFE 3.0.2

LIFE is an Android personal dashboard built around a single WebView core (`app/src/main/assets/index.html`) with native Android bridges for notifications, Health Connect, reminders and the home-screen widget.

## Build

GitHub Actions uses Java 17 and forces both Java and Kotlin compilation targets to JVM 17 to avoid inconsistent JVM-target errors.

## Included

- Liquid Glass style LIFE dashboard
- tasks, focus, health, water, sleep, mood
- nutrition and finance sections
- study timer and weekly plan
- transport passes and expiry reminders
- calendar and statistics
- local AI coach/digest logic
- Android notifications
- Health Connect permissions and daily aggregation
- home-screen widget
- import/export/reset

## AI security

Do not put an OpenAI API key in the APK, HTML, GitHub repository, or client-side JavaScript. A real generative AI connection should use a secure server-side proxy.
