package com.timur.life

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZonedDateTime
import java.util.Calendar

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var healthClient: HealthConnectClient? = null
    private var healthPermissionLauncher: ActivityResultLauncher<Set<String>>? = null
    private val channelId = "life_general"

    private val healthPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "LIFE", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        healthClient = try { HealthConnectClient.getOrCreate(this) } catch (_: Exception) { null }
        healthClient?.let { client ->
            healthPermissionLauncher = registerForActivityResult(
                client.permissionController.createRequestPermissionResultContract()
            ) { syncHealthToWeb() }
        }
        web = WebView(this).apply {
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            addJavascriptInterface(LifeBridge(), "LIFEAndroid")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    private fun syncHealthToWeb() {
        val client = healthClient ?: return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val now = ZonedDateTime.now()
                val filter = TimeRangeFilter.between(now.toLocalDate().atStartOfDay(now.zone).toInstant(), Instant.now())
                val result = client.aggregate(AggregateRequest(
                    metrics = setOf(StepsRecord.COUNT_TOTAL, DistanceRecord.DISTANCE_TOTAL, ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
                    timeRangeFilter = filter
                ))
                val steps = result[StepsRecord.COUNT_TOTAL] ?: 0L
                val distance = result[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0
                val calories = result[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
                withContext(Dispatchers.Main) {
                    web.evaluateJavascript("window.LIFEHealth && window.LIFEHealth($steps,$distance,$calories);", null)
                }
            } catch (_: Exception) { }
        }
    }

    inner class LifeBridge {
        @JavascriptInterface fun notify(title: String, text: String) {
            val n = NotificationCompat.Builder(this@MainActivity, channelId)
                .setSmallIcon(R.drawable.ic_life).setContentTitle(title.take(80)).setContentText(text.take(180))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).build()
            getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
        }
        @JavascriptInterface fun openHealth() {
            try { startActivity(Intent("androidx.health.ACTION_HEALTH_CONNECT_SETTINGS")) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        @JavascriptInterface fun connectHealth() {
            val client = healthClient ?: run { openHealth(); return }
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val missing = healthPermissions - client.permissionController.getGrantedPermissions()
                    withContext(Dispatchers.Main) {
                        if (missing.isNotEmpty()) healthPermissionLauncher?.launch(missing) ?: openHealth() else syncHealthToWeb()
                    }
                } catch (_: Exception) { withContext(Dispatchers.Main) { openHealth() } }
            }
        }
        @JavascriptInterface fun refreshHealth() = syncHealthToWeb()
        @JavascriptInterface fun scheduleDaily(title: String, text: String, hour: Int, minute: Int) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            val intent = Intent(this@MainActivity, ReminderReceiver::class.java).apply { putExtra("title", title); putExtra("text", text) }
            val pi = PendingIntent.getBroadcast(this@MainActivity, (title.hashCode() and 0x7fffffff), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour.coerceIn(0,23)); set(Calendar.MINUTE, minute.coerceIn(0,59)); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0); if(timeInMillis<=System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1) }
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        }
        @JavascriptInterface fun openUrl(url: String) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} }
    }

    override fun onResume() { super.onResume(); if (::web.isInitialized) syncHealthToWeb() }
    @Deprecated("Deprecated in Android API") override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
}
