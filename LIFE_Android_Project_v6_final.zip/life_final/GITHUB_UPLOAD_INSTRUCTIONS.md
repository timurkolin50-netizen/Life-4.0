# LIFE 3.0.1 — GitHub upload

Important: upload the **contents of this folder** into the repository root.
Do NOT upload this ZIP as a single file.

Required files include:
- app/src/main/res/xml/life_widget_info.xml
- app/src/main/res/layout/life_widget.xml
- app/src/main/AndroidManifest.xml

After upload, verify on GitHub that this exact path exists:
`app/src/main/res/xml/life_widget_info.xml`

Then run Actions → Build LIFE APK → Run workflow.
