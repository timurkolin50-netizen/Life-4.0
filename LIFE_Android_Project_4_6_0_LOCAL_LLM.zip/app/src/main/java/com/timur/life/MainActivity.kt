package com.timur.life

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.app.KeyguardManager
import android.widget.Toast
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.contracts.HealthPermissionsRequestContract
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZonedDateTime
import java.time.ZoneId
import java.util.Calendar

class MainActivity : ComponentActivity() {
    companion object {
        init { System.loadLibrary("life_llama") }
        @JvmStatic private external fun nativeLoadModel(path: String, threads: Int): Boolean
        @JvmStatic private external fun nativeGenerate(path: String, prompt: String, maxTokens: Int, temperature: Float, threads: Int): String
        @JvmStatic private external fun nativeUnload()
        @JvmStatic private external fun nativeModelLoaded(): Boolean
    }
    private lateinit var web: WebView
    private var healthClient: HealthConnectClient? = null
    private var healthPermissionLauncher: ActivityResultLauncher<Set<String>>? = null
    private var securityPromptShown = false
    private val securityRequestCode = 9201
    private val modelPickRequestCode = 9301
    private val channelId = "life_general"
    private val healthChannelId = "life_health"
    private val lifeZone = ZoneId.of("Europe/Vilnius")
    private val healthHandler = Handler(Looper.getMainLooper())
    @Volatile private var healthSyncRunning = false
    private val healthPoll = object : Runnable {
        override fun run() {
            syncHealthToWeb()
            syncHealthHistoryToWeb()
            healthHandler.postDelayed(this, 30_000L)
        }
    }

    private val healthPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        healthPermissionLauncher = registerForActivityResult(
            HealthPermissionsRequestContract()
        ) {
            healthClient = try {
                HealthConnectClient.getOrCreate(this@MainActivity)
            } catch (_: Exception) {
                null
            }
            syncHealthToWeb()
        }


        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                100
            )
        }

        if (Build.VERSION.SDK_INT >= 26) {
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(
                NotificationChannel(channelId, "LIFE", NotificationManager.IMPORTANCE_DEFAULT)
            )
            notificationManager.createNotificationChannel(
                NotificationChannel(healthChannelId, "Здоровье", NotificationManager.IMPORTANCE_HIGH)
            )
        }

        web = WebView(this).apply {
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            addJavascriptInterface(LifeBridge(), "LIFEAndroid")
            loadUrl("file:///android_asset/index.html")
        }

        setContentView(web)
        val remindersEnabled = getSharedPreferences("life_settings", MODE_PRIVATE).getBoolean("health_reminders_enabled", true)
        if (remindersEnabled) ReminderScheduler.schedule(this)
    }

    override fun onResume() {
        super.onResume()
        if (isAppLockEnabled() && !securityPromptShown) {
            securityPromptShown = true
            requestDeviceUnlock()
        }
        healthClient = try {
            HealthConnectClient.getOrCreate(this)
        } catch (_: Exception) {
            null
        }
        syncHealthToWeb()
        syncHealthHistoryToWeb()
        healthHandler.removeCallbacks(healthPoll)
        healthHandler.postDelayed(healthPoll, 1_000L)
    }

    override fun onPause() {
        healthHandler.removeCallbacks(healthPoll)
        super.onPause()
    }

    private fun modelDir(): File = File(filesDir, "ai_models")

    private fun installedModel(): File? = modelDir().listFiles()?.firstOrNull { it.isFile && it.name.endsWith(".gguf", true) }

    private fun modelInfoJson(): String {
        val f = installedModel() ?: return "{\"ready\":false}"
        return "{\"ready\":true,\"name\":${org.json.JSONObject.quote(f.name)},\"size\":${f.length()}}"
    }

    private fun pickLocalModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
        }
        startActivityForResult(intent, modelPickRequestCode)
    }

    private fun deleteLocalModel() {
        installedModel()?.delete()
        web.post { web.evaluateJavascript("window.onLIFEModelSelected && window.onLIFEModelSelected(${modelInfoJson()})", null) }
    }

    private fun isAppLockEnabled(): Boolean =
        getSharedPreferences("life_settings", MODE_PRIVATE).getBoolean("app_lock", false)

    private fun requestDeviceUnlock() {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardSecure) {
            Toast.makeText(this, "Сначала настрой блокировку экрана Android", Toast.LENGTH_LONG).show()
            securityPromptShown = false
            return
        }
        val intent = km.createConfirmDeviceCredentialIntent("Защита LIFE", "Подтверди личность для доступа к LIFE")
        if (intent != null) startActivityForResult(intent, securityRequestCode) else securityPromptShown = false
    }

    @Deprecated("Deprecated in Android API; retained for device credential compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == modelPickRequestCode && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri == null) return
            try {
                val dir = modelDir().apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                var name = "life-model.gguf"
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) name = c.getString(0) ?: name
                }
                if (!name.endsWith(".gguf", true)) name += ".gguf"
                val out = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(out).use { output -> input.copyTo(output) }
                } ?: throw IllegalStateException("Не удалось открыть модель")
                web.post { web.evaluateJavascript("window.onLIFEModelSelected && window.onLIFEModelSelected(${modelInfoJson()})", null) }
                Toast.makeText(this, "Модель LIFE AI сохранена", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось сохранить модель", Toast.LENGTH_LONG).show()
            }
            return
        }

        if (requestCode == securityRequestCode) {
            if (resultCode != RESULT_OK) finish()
            else securityPromptShown = true
        }
    }

    private fun getHealthClient(): HealthConnectClient? {
        if (healthClient == null) {
            healthClient = try { HealthConnectClient.getOrCreate(this) } catch (_: Exception) { null }
        }
        return healthClient
    }

    private fun syncHealthToWeb() {
        val client = getHealthClient() ?: return
        if (healthSyncRunning) return
        healthSyncRunning = true

        CoroutineScope(Dispatchers.IO).launch {
            val now = ZonedDateTime.now(lifeZone)
            val start = now.toLocalDate().atStartOfDay(lifeZone).toInstant()
            val range = TimeRangeFilter.between(start, Instant.now())

            var steps = 0L
            var distance = 0.0
            var calories = 0.0

            try {
                val result = client.aggregate(
                    AggregateRequest(
                        metrics = setOf(StepsRecord.COUNT_TOTAL),
                        timeRangeFilter = range
                    )
                )
                steps = result[StepsRecord.COUNT_TOTAL] ?: 0L
            } catch (_: Exception) {}

            try {
                val result = client.aggregate(
                    AggregateRequest(
                        metrics = setOf(DistanceRecord.DISTANCE_TOTAL),
                        timeRangeFilter = range
                    )
                )
                distance = result[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0
            } catch (_: Exception) {}

            try {
                val result = client.aggregate(
                    AggregateRequest(
                        metrics = setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
                        timeRangeFilter = range
                    )
                )
                calories = result[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
            } catch (_: Exception) {}

            withContext(Dispatchers.Main) {
                if (::web.isInitialized) {
                    web.evaluateJavascript(
                        "window.LIFEHealth && window.LIFEHealth($steps,$distance,$calories);",
                        null
                    )
                }
                healthSyncRunning = false
            }
        }
    }

    private fun syncHealthHistoryToWeb() {
        val client = getHealthClient() ?: return

        CoroutineScope(Dispatchers.IO).launch {
            val today = ZonedDateTime.now(lifeZone).toLocalDate()
            val values = mutableListOf<String>()

            for (offset in 6 downTo 0) {
                val date = today.minusDays(offset.toLong())
                val start = date.atStartOfDay(lifeZone).toInstant()
                val end = date.plusDays(1).atStartOfDay(lifeZone).toInstant()

                var steps: Long? = null
                try {
                    val result = client.aggregate(
                        AggregateRequest(
                            metrics = setOf(StepsRecord.COUNT_TOTAL),
                            timeRangeFilter = TimeRangeFilter.between(start, end)
                        )
                    )
                    steps = result[StepsRecord.COUNT_TOTAL] ?: 0L
                } catch (_: Exception) {
                    // Never replace a previously known day with zero when Health Connect
                    // temporarily refuses access or is unavailable.
                }

                val label = when (date.dayOfWeek.value) {
                    1 -> "Пн"; 2 -> "Вт"; 3 -> "Ср"; 4 -> "Чт"
                    5 -> "Пт"; 6 -> "Сб"; else -> "Вс"
                }
                if (steps != null) values += """{"date":"$date","label":"$label","steps":$steps}"""
            }

            withContext(Dispatchers.Main) {
                if (::web.isInitialized) {
                    val json = values.joinToString(",", "[", "]")
                    web.evaluateJavascript(
                        "window.LIFEHealthHistory && window.LIFEHealthHistory($json);",
                        null
                    )
                }
            }
        }
    }

    inner class LifeBridge {
        @JavascriptInterface
        fun notify(title: String, text: String) {
            val selectedChannel = if (title.contains("вода", true) || title.contains("ход", true) || title.contains("сон", true) || title.contains("здоров", true)) healthChannelId else channelId
            val notification = NotificationCompat.Builder(this@MainActivity, selectedChannel)
                .setSmallIcon(R.drawable.ic_life)
                .setContentTitle(title.take(80))
                .setContentText(text.take(180))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()

            getSystemService(NotificationManager::class.java).notify(
                (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
                notification
            )
        }

        @JavascriptInterface
        fun openHealth() {
            try {
                val intent = Intent(
                    "android.health.connect.action.MANAGE_HEALTH_PERMISSIONS"
                ).apply {
                    putExtra(Intent.EXTRA_PACKAGE_NAME, packageName)
                }
                startActivity(intent)
                return
            } catch (_: Exception) {
                // Continue with the Health Connect settings intent.
            }

            try {
                startActivity(
                    HealthConnectClient.getHealthConnectManageDataIntent(
                        this@MainActivity
                    )
                )
            } catch (_: Exception) {
                try {
                    startActivity(Intent(HealthConnectClient.ACTION_HEALTH_CONNECT_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(
                        this@MainActivity,
                        "Не удалось открыть Health Connect",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        @JavascriptInterface
        fun connectHealth() {
            // Open the official Health Connect permissions UI directly for LIFE.
            // This bypasses SDK-status checks and lets Android/Health Connect
            // handle the permission screen.
            try {
                val intent = Intent(
                    "android.health.connect.action.MANAGE_HEALTH_PERMISSIONS"
                ).apply {
                    putExtra(Intent.EXTRA_PACKAGE_NAME, packageName)
                }
                startActivity(intent)
            } catch (_: Exception) {
                // Fallback: open the main Health Connect UI.
                try {
                    startActivity(
                        HealthConnectClient.getHealthConnectManageDataIntent(
                            this@MainActivity
                        )
                    )
                } catch (_: Exception) {
                    try {
                        startActivity(
                            Intent(HealthConnectClient.ACTION_HEALTH_CONNECT_SETTINGS)
                        )
                    } catch (_: Exception) {
                        Toast.makeText(
                            this@MainActivity,
                            "Не удалось открыть Health Connect",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }

        @JavascriptInterface
        fun scheduleHealthReminders(enabled: Boolean) {
            getSharedPreferences("life_settings", MODE_PRIVATE).edit().putBoolean("health_reminders_enabled", enabled).apply()
            if (enabled) ReminderScheduler.schedule(this@MainActivity)
            else ReminderScheduler.cancel(this@MainActivity)
        }

        @JavascriptInterface
        fun refreshHealth() {
            syncHealthToWeb()
            syncHealthHistoryToWeb()
        }

        @JavascriptInterface
        fun setAppLock(enabled: Boolean) {
            getSharedPreferences("life_settings", MODE_PRIVATE).edit().putBoolean("app_lock", enabled).apply()
            if (enabled) requestDeviceUnlock()
            else securityPromptShown = true
        }

        @JavascriptInterface
        fun pickAIModel() { runOnUiThread { pickLocalModel() } }

        @JavascriptInterface
        fun aiModelInfo(): String = modelInfoJson()

        @JavascriptInterface
        fun deleteAIModel() {
            try { nativeUnload() } catch (_: Throwable) {}
            deleteLocalModel()
        }

        @JavascriptInterface
        fun loadAIModel(): Boolean {
            val model = installedModel() ?: return false
            return try { nativeLoadModel(model.absolutePath, Runtime.getRuntime().availableProcessors().coerceIn(2, 8)) } catch (_: Throwable) { false }
        }

        @JavascriptInterface
        fun askAI(prompt: String, context: String) {
            val model = installedModel()
            if (model == null) {
                web.post { web.evaluateJavascript("window.onLIFEAIAnswer && window.onLIFEAIAnswer('Модель LIFE AI не установлена. Сначала выбери GGUF-файл.')", null) }
                return
            }
            val fullPrompt = "Ты — LIFE AI, локальный помощник приложения LIFE. Отвечай по-русски, кратко и по делу. Не выдумывай факты. Используй данные LIFE только как контекст. Если пользователь просит изменить данные приложения, сначала попроси подтверждение. /no_think\n\nКОНТЕКСТ LIFE:\n$context\n\nЗАПРОС ПОЛЬЗОВАТЕЛЯ:\n$prompt\n\nОТВЕТ:"
            CoroutineScope(Dispatchers.Default).launch {
                val answer = try {
                    nativeGenerate(model.absolutePath, fullPrompt, 512, 0.45f, Runtime.getRuntime().availableProcessors().coerceIn(2, 8))
                } catch (e: Throwable) {
                    "Ошибка локального AI: ${e.message ?: "неизвестная ошибка"}"
                }
                val quoted = org.json.JSONObject.quote(answer)
                withContext(Dispatchers.Main) {
                    if (::web.isInitialized) web.evaluateJavascript("window.onLIFEAIAnswer && window.onLIFEAIAnswer($quoted)", null)
                }
            }
        }

        @JavascriptInterface
        fun appLockEnabled(): Boolean = this@MainActivity.isAppLockEnabled()


        @JavascriptInterface
        fun schedulePlanItem(id: Long, title: String, hour: Int, minute: Int, repeat: String = "none", reminderMinutes: Int = 0) {
            try {
                PlanReminderReceiver.schedule(this@MainActivity, id, title, hour, minute, repeat, reminderMinutes)
                return
                val now = ZonedDateTime.now(lifeZone)
                val whenTime = now.toLocalDate().atTime(hour.coerceIn(0, 23), minute.coerceIn(0, 59)).atZone(lifeZone)
                if (!whenTime.isAfter(now)) return
                val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
                val intent = Intent(this@MainActivity, ReminderReceiver::class.java).apply {
                    putExtra("title", "LIFE · План")
                    putExtra("text", title.take(180))
                }
                val pending = PendingIntent.getBroadcast(
                    this@MainActivity, (id and 0x7fffffff).toInt(), intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenTime.toInstant().toEpochMilli(), pending)
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun cancelPlanItem(id: Long) {
            try {
                PlanReminderReceiver.cancel(this@MainActivity, id)

                val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
                val intent = Intent(this@MainActivity, ReminderReceiver::class.java)
                val pending = PendingIntent.getBroadcast(
                    this@MainActivity, (id and 0x7fffffff).toInt(), intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                alarmManager.cancel(pending)
                pending.cancel()
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun scheduleDaily(title: String, text: String, hour: Int, minute: Int) {
            val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
            val intent = Intent(this@MainActivity, ReminderReceiver::class.java).apply {
                putExtra("title", title)
                putExtra("text", text)
            }
            val requestCode = title.hashCode() and 0x7fffffff
            val pendingIntent = PendingIntent.getBroadcast(
                this@MainActivity,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
                set(Calendar.MINUTE, minute.coerceIn(0, 59))
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }

            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                pendingIntent
            )
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            try {
                val uri = Uri.parse(url)
                val allowed = uri.scheme == "https" &&
                    (uri.host == "chatgpt.com" || uri.host == "www.chatgpt.com")
                if (!allowed) return
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (_: Exception) {
                // Ignore invalid or unsupported URLs.
            }
        }
    }

    override fun onDestroy() {
        try { nativeUnload() } catch (_: Throwable) {}
        if (::web.isInitialized) {
            web.removeJavascriptInterface("LIFEAndroid")
            web.destroy()
        }
        super.onDestroy()
    }
}
