package com.timur.life

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.contracts.HealthPermissionsRequestContract
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZonedDateTime
import java.util.Calendar

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var healthClient: HealthConnectClient? = null
    private var healthPermissionLauncher: ActivityResultLauncher<Set<String>>? = null
    private val channelId = "life_general"

    private val healthPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                100
            )
        }

        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(
                    channelId,
                    "LIFE",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
            )
        }

        // Register the Health Connect permission launcher unconditionally.
        // This prevents the button from becoming a silent no-op when the
        // provider status is different from SDK_AVAILABLE.
        healthPermissionLauncher = registerForActivityResult(
            HealthPermissionsRequestContract()
        ) {
            syncHealthToWeb()
        }

        val healthStatus = try {
            HealthConnectClient.getSdkStatus(this)
        } catch (_: Exception) {
            HealthConnectClient.SDK_UNAVAILABLE
        }

        if (healthStatus == HealthConnectClient.SDK_AVAILABLE) {
            healthClient = try {
                HealthConnectClient.getOrCreate(this)
            } catch (_: Exception) {
                null
            }
        }

        web = WebView(this).apply {
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            addJavascriptInterface(LifeBridge(), "LIFEAndroid")
            loadUrl("file:///android_asset/index.html")
        }

        setContentView(web)
    }

    private fun syncHealthToWeb() {
        val client = healthClient ?: return

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val now = ZonedDateTime.now()
                val start = now.toLocalDate().atStartOfDay(now.zone).toInstant()
                val result = client.aggregate(
                    AggregateRequest(
                        metrics = setOf(
                            StepsRecord.COUNT_TOTAL,
                            DistanceRecord.DISTANCE_TOTAL,
                            ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL
                        ),
                        timeRangeFilter = TimeRangeFilter.between(start, Instant.now())
                    )
                )

                val steps = result[StepsRecord.COUNT_TOTAL] ?: 0L
                val distance = result[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0
                val calories = result[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0

                withContext(Dispatchers.Main) {
                    if (::web.isInitialized) {
                        web.evaluateJavascript(
                            "window.LIFEHealth && window.LIFEHealth($steps,$distance,$calories);",
                            null
                        )
                    }
                }
            } catch (_: Exception) {
                // Health Connect may be unavailable or permissions may not be granted yet.
            }
        }
    }

    inner class LifeBridge {
        @JavascriptInterface
        fun notify(title: String, text: String) {
            val notification = NotificationCompat.Builder(this@MainActivity, channelId)
                .setSmallIcon(R.drawable.ic_life)
                .setContentTitle(title.take(80))
                .setContentText(text.take(180))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()

            getSystemService(NotificationManager::class.java).notify(
                (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
                notification
            )
        }

        @JavascriptInterface
        fun openHealth() {
            // First try the Health Connect app directly. On Android versions
            // where it is a separate provider package, this reliably opens
            // the Health Connect UI.
            try {
                val launchIntent =
                    packageManager.getLaunchIntentForPackage("com.google.android.apps.healthdata")
                if (launchIntent != null) {
                    startActivity(launchIntent)
                    return
                }
            } catch (_: Exception) {
                // Continue with the official Health Connect intents.
            }

            val intents = listOf(
                HealthConnectClient.getHealthConnectManageDataIntent(this@MainActivity),
                Intent(HealthConnectClient.ACTION_HEALTH_CONNECT_SETTINGS),
                Intent("android.health.connect.action.HEALTH_CONNECT_SETTINGS")
            )

            for (intent in intents) {
                try {
                    if (intent.resolveActivity(packageManager) != null) {
                        startActivity(intent)
                        return
                    }
                } catch (_: Exception) {
                    // Try the next supported Health Connect intent.
                }
            }

            Toast.makeText(
                this@MainActivity,
                "Health Connect не найден в системе",
                Toast.LENGTH_LONG
            ).show()
        }

        @JavascriptInterface
        fun connectHealth() {
            // Diagnostic: prove that the JavaScript bridge reaches Android.
            Toast.makeText(
                this@MainActivity,
                "LIFE: Android-мост работает",
                Toast.LENGTH_SHORT
            ).show()

            val status = try {
                HealthConnectClient.getSdkStatus(this@MainActivity)
            } catch (_: Exception) {
                HealthConnectClient.SDK_UNAVAILABLE
            }

            if (status != HealthConnectClient.SDK_AVAILABLE) {
                Toast.makeText(
                    this@MainActivity,
                    "Health Connect недоступен для LIFE",
                    Toast.LENGTH_LONG
                ).show()
                openHealth()
                return
            }

            val client = try {
                healthClient ?: HealthConnectClient.getOrCreate(this@MainActivity).also {
                    healthClient = it
                }
            } catch (_: Exception) {
                null
            }

            if (client == null) {
                Toast.makeText(
                    this@MainActivity,
                    "Не удалось подключить Health Connect",
                    Toast.LENGTH_LONG
                ).show()
                openHealth()
                return
            }

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val missing =
                        healthPermissions - client.permissionController.getGrantedPermissions()

                    withContext(Dispatchers.Main) {
                        if (missing.isNotEmpty()) {
                            val launcher = healthPermissionLauncher
                            if (launcher != null) {
                                // This is the critical step: requesting the
                                // permissions causes LIFE to appear in the
                                // Health Connect app-permissions list.
                                launcher.launch(missing)
                            } else {
                                Toast.makeText(
                                    this@MainActivity,
                                    "Окно разрешений Health Connect не готово",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        } else {
                            Toast.makeText(
                                this@MainActivity,
                                "Health Connect уже подключён к LIFE",
                                Toast.LENGTH_SHORT
                            ).show()
                            syncHealthToWeb()
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@MainActivity,
                            "Ошибка Health Connect: " +
                                (e.message ?: "неизвестная ошибка"),
                            Toast.LENGTH_LONG
                        ).show()
                        openHealth()
                    }
                }
            }
        }

        @JavascriptInterface
        fun refreshHealth() {
            syncHealthToWeb()
        }

        @JavascriptInterface
        fun scheduleDaily(title: String, text: String, hour: Int, minute: Int) {
            val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
            val intent = Intent(this@MainActivity, ReminderReceiver::class.java).apply {
                putExtra("title", title)
                putExtra("text", text)
            }
            val requestCode = title.hashCode() and 0x7fffffff
            val pendingIntent = PendingIntent.getBroadcast(
                this@MainActivity,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
                set(Calendar.MINUTE, minute.coerceIn(0, 59))
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }

            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                pendingIntent
            )
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Exception) {
                // Ignore invalid or unsupported URLs.
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) syncHealthToWeb()
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.removeJavascriptInterface("LIFEAndroid")
            web.destroy()
        }
        super.onDestroy()
    }
}
