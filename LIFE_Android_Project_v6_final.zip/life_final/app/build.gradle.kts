plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.timur.life"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.timur.life"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "3.0.1"
    }
}


dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.health.connect:connect-client:1.1.0-alpha07")
}
