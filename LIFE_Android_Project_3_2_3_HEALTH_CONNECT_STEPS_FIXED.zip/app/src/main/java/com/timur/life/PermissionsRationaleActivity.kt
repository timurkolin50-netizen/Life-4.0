package com.timur.life

import android.os.Bundle
import android.webkit.WebView
import android.widget.TextView
import androidx.activity.ComponentActivity

class PermissionsRationaleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val text = TextView(this).apply {
            text = "LIFE использует данные Health Connect для отображения активности, шагов, сна, пульса, расстояния и активных калорий в приложении. Данные используются только для функций LIFE."
            textSize = 18f
            setPadding(48, 48, 48, 48)
        }
        setContentView(text)
    }
}
