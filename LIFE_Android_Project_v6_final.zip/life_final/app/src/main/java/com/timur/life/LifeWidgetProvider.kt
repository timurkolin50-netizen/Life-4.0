package com.timur.life

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZonedDateTime

class LifeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val now = ZonedDateTime.now()
        val time = now.toLocalTime().toString().take(5)
        val date = now.toLocalDate().toString()
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.life_widget)
            views.setTextViewText(R.id.widget_time, time)
            views.setTextViewText(R.id.widget_info, "Сегодня • $date")
            views.setOnClickPendingIntent(id, PendingIntent.getActivity(context, id, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            manager.updateAppWidget(id, views)
        }
        try {
            val client = HealthConnectClient.getOrCreate(context)
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val filter = TimeRangeFilter.between(now.toLocalDate().atStartOfDay(now.zone).toInstant(), Instant.now())
                    val result = client.aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), filter))
                    val steps = result[StepsRecord.COUNT_TOTAL] ?: 0L
                    ids.forEach { id ->
                        val views = RemoteViews(context.packageName, R.layout.life_widget)
                        views.setTextViewText(R.id.widget_time, time)
                        views.setTextViewText(R.id.widget_info, "Сегодня • ${steps} шагов")
                        views.setOnClickPendingIntent(id, PendingIntent.getActivity(context, id, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                        manager.updateAppWidget(id, views)
                    }
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }
}
