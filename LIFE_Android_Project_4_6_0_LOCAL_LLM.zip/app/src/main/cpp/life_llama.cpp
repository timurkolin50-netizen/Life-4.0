#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include "llama.h"

#define TAG "LIFE-AI"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::mutex g_mutex;
static llama_model * g_model = nullptr;
static llama_context * g_ctx = nullptr;
static std::string g_path;
static const llama_vocab * g_vocab = nullptr;

static void unload_locked() {
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_vocab = nullptr;
    g_path.clear();
    llama_backend_free();
}

static bool load_locked(const std::string & path, int threads) {
    if (g_model && g_ctx && g_path == path) return true;
    unload_locked();
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0; // CPU first: portable and stable on Android arm64.
    g_model = llama_model_load_from_file(path.c_str(), mp);
    if (!g_model) { LOGE("model load failed: %s", path.c_str()); unload_locked(); return false; }
    g_vocab = llama_model_get_vocab(g_model);
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = 4096;
    cp.n_batch = 512;
    cp.n_ubatch = 512;
    cp.n_threads = std::max(1, std::min(8, threads));
    cp.n_threads_batch = cp.n_threads;
    cp.no_perf = true;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { LOGE("context creation failed"); unload_locked(); return false; }
    g_path = path;
    return true;
}

static std::string jstring_to_string(JNIEnv * env, jstring s) {
    if (!s) return {};
    const char * p = env->GetStringUTFChars(s, nullptr);
    std::string out = p ? p : "";
    if (p) env->ReleaseStringUTFChars(s, p);
    return out;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_timur_life_MainActivity_nativeLoadModel(JNIEnv * env, jclass, jstring path, jint threads) {
    std::lock_guard<std::mutex> lock(g_mutex);
    return load_locked(jstring_to_string(env, path), threads) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_timur_life_MainActivity_nativeGenerate(JNIEnv * env, jclass, jstring path, jstring prompt, jint maxTokens, jfloat temperature, jint threads) {
    std::lock_guard<std::mutex> lock(g_mutex);
    const std::string modelPath = jstring_to_string(env, path);
    const std::string userPrompt = jstring_to_string(env, prompt);
    if (!load_locked(modelPath, threads)) return env->NewStringUTF("Не удалось загрузить локальную AI-модель.");

    const int limit = std::max(1, std::min(2048, (int)maxTokens));
    const int n_prompt = -llama_tokenize(g_vocab, userPrompt.c_str(), (int)userPrompt.size(), nullptr, 0, true, true);
    if (n_prompt <= 0 || n_prompt > 3500) return env->NewStringUTF("Слишком большой контекст для локальной модели.");
    std::vector<llama_token> tokens(n_prompt);
    if (llama_tokenize(g_vocab, userPrompt.c_str(), (int)userPrompt.size(), tokens.data(), (int)tokens.size(), true, true) < 0)
        return env->NewStringUTF("Не удалось подготовить запрос для модели.");

    llama_memory_clear(llama_get_memory(g_ctx), true);
    llama_sampler * sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (temperature <= 0.05f) {
        llama_sampler_chain_add(sampler, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(sampler, llama_sampler_init_temp(temperature));
        llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.95f, 1));
        llama_sampler_chain_add(sampler, llama_sampler_init_dist(42));
    }

    llama_batch batch = llama_batch_get_one(tokens.data(), tokens.size());
    if (llama_decode(g_ctx, batch) != 0) {
        llama_sampler_free(sampler); return env->NewStringUTF("Модель не смогла обработать запрос.");
    }

    std::string output;
    int generated = 0;
    while (generated < limit) {
        llama_token tok = llama_sampler_sample(sampler, g_ctx, -1);
        if (llama_vocab_is_eog(g_vocab, tok)) break;
        char buf[256];
        int n = llama_token_to_piece(g_vocab, tok, buf, sizeof(buf), 0, true);
        if (n > 0) output.append(buf, n);
        batch = llama_batch_get_one(&tok, 1);
        if (llama_decode(g_ctx, batch) != 0) break;
        generated++;
    }
    llama_sampler_free(sampler);
    if (output.empty()) output = "Локальная модель не вернула ответ.";
    return env->NewStringUTF(output.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_timur_life_MainActivity_nativeUnload(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    unload_locked();
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_timur_life_MainActivity_nativeModelLoaded(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    return (g_model && g_ctx) ? JNI_TRUE : JNI_FALSE;
}
