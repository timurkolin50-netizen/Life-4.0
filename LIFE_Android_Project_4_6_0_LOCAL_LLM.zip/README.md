# LIFE 4.6.0 — Local AI Engine

Подключён локальный GGUF inference через llama.cpp и Android NDK. Модель не входит в репозиторий: пользователь выбирает GGUF-файл, LIFE хранит его во внутреннем хранилище и загружает локально. Сборка native-движка выполняется GitHub Actions через pinned llama.cpp build b10819.

Рекомендуемая модель для OnePlus Nord 4: Qwen3-4B Q4_K_M или близкая по размеру GGUF-квантизация. Модель в APK не включается.
